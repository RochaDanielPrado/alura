export interface UsuarioCadastrarDto{
    nome: string;
    email: string;
    senha: string;
    telefone: string;
    cpf: string;
}