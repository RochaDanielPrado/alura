export const jwtConstants = {
    secret: 'minha-api-e-segura-top',
  };