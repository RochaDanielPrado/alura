export interface ServicoCadastrarDto{
    titulo: string;
    descricao: string;
}