export interface RefreshTokenDto{
    oldToken: string
}